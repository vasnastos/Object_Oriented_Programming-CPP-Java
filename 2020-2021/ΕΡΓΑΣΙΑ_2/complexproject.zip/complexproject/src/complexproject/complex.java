/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package complexproject;

/**
 *
 * @author Administrator
 */
public class complex {
    private double real;
    private double imaginary;
    public complex()
    {
        this.real=0.0;
        this.imaginary=0.0;
    }
    public complex(double r,double im)
    {
        this.real=r;
        this.imaginary=im;
    }
    public void set_real(double a_real)
    {
        this.real=a_real;
    }
    public void set_Imaginary(double a_imaginary)
    {
        this.imaginary=a_imaginary;
    }
    public double getReal()
    {
        return this.real;
    }
    public double getImaginary()
    {
        return this.imaginary;
    }
    public complex add(complex c1,complex c2)
    {
        complex addres=new complex();
        addres.real=c1.real+c2.real;
        addres.imaginary=c1.imaginary+c2.imaginary;
        return addres;
    }
    public complex minus(complex c1,complex c2)
    {
        complex m=new complex();
        m.real=c1.real-c2.real;
        m.imaginary=c1.imaginary-c2.imaginary;
        return m;
    }
    public complex div(complex c1,complex c2)
    {
        complex divres=new complex();
        divres.real=c1.real/c2.real;
        divres.imaginary=c1.imaginary/c2.imaginary;
        return divres;
    }
    public complex mul(complex c1,complex c2)
    {
        complex ml=new complex();
        ml.real=c1.real*c2.real;
        ml.imaginary=c1.imaginary*c2.imaginary;
        return ml;
    }
    public String to_Str()
    {
        String msg="";
        if(this.imaginary>0)
        {
            msg+=String.valueOf(this.real)+"+"+String.valueOf(this.imaginary)+"i";
        }
        else
        {
            msg+=String.valueOf(this.real)+String.valueOf(this.imaginary)+"i";
        }
        return msg;
    }
}
