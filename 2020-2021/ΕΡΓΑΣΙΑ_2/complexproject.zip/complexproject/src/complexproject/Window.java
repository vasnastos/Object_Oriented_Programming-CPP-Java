/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package complexproject;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Administrator
 */
public class Window extends JFrame{
    private JPanel p2,p3;
    private String ops[]={"+","-","*","/"};
    private JComboBox <String> operators=new JComboBox<String>(ops);
    private JLabel result=null;
    private void panel1()
    {
        JLabel lbl=new JLabel();
        lbl.setSize((int)(0.98*this.getWidth()),(int)(0.3*this.getHeight()));
        ImageIcon ic=new ImageIcon(new ImageIcon("complex.png").getImage().getScaledInstance(lbl.getWidth(),lbl.getHeight(),Image.SCALE_REPLICATE));
        lbl.setIcon(ic);
        this.add(lbl);
    }
    private void panel2()
    {
        p2=new JPanel();
        p2.setLayout(new FlowLayout(FlowLayout.CENTER,10,10));
        p2.setSize((int)(0.98*this.getWidth()),(int)(0.3*this.getHeight()));
        JTextField f1=new JTextField(5);
        f1.setToolTipText("Insert first Complex");
        JTextField f2=new JTextField(5);
         f2.setToolTipText("Insert Second Complex");
        JButton b1=new JButton("Calculate");
        b1.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae)
            {
                String cmp1=f1.getText();
                String cmp2=f2.getText();
                if(cmp1.length()==0 || cmp2.length()==0)
                {
                    JOptionPane.showMessageDialog(null,"Fill all the blanks!!!");
                    return;
                }
                if(!f1.getText().contains("i") || !f2.getText().contains("i"))
                {
                    JOptionPane.showMessageDialog(null,"Please fill the blanks with complex numbers");
                    return;
                }
                String list1[]=cmp1.split("[+]");
                String list2[]=cmp2.split("[+]");
                String list3[]=cmp1.split("-");
                String list4[]=cmp2.split("-");
                complex c1=new complex();
                complex c2=new complex();
                if(list1.length==2)
                {
                    if(!list1[1].contains("i"))
                    {
                        JOptionPane.showMessageDialog(null,"Not a complex number<br><b>EX:n1+n2i</b>");
                        return;
                    }
                    String splt[]=list1[1].split("i");
                    c1.set_real(Double.parseDouble(list1[0]));
                    c1.set_Imaginary(Double.parseDouble(splt[0]));
                }
                else if(list3.length==2)
                {
                    if(!list3[1].contains("i"))
                    {
                        JOptionPane.showMessageDialog(null,"Not a complex number<br><b>EX:n1+n2i</b>");
                        return;
                    }
                    String splt[]=list3[1].split("i");
                    c1.set_real(Double.parseDouble(list3[0]));
                    double num=0.0;
                    if(splt[0].equals(""))
                    {
                        num=0.0;
                    }
                    else 
                    {
                        num=Double.parseDouble(splt[0]);
                    }
                    c1.set_Imaginary(-num);
                }
                else
                {
                    JOptionPane.showMessageDialog(null,"<html><i>Invallid complex number--"+f1.getText()+"</i><html>");
                    return;
                }
                if(list2.length==2)
                {
                    if(list2[1].indexOf("i")==-1)
                    {
                        JOptionPane.showMessageDialog(null,"Not a complex number<br><b>EX:n1+n2i</b>");
                        return;
                    }
                    String splt[]=list2[1].split("i");
                    c2.set_real(Double.parseDouble(list2[0]));
                    c2.set_Imaginary(Double.parseDouble(splt[0]));
                }
                else if(list4.length==2)
                {
                    if(list4[1].indexOf("i")==-1)
                    {
                        JOptionPane.showMessageDialog(null,"Not a complex number<br><b>EX:n1+n2i</b>");
                        return;
                    }
                    String splt[]=list4[1].split("i");
                    c2.set_real(Double.parseDouble(list4[0]));
                    double num=0.0;
                    if(splt[0].equals(""))
                    {
                        num=0.0;
                    }
                    else 
                    {
                        num=Double.parseDouble(splt[0]);
                    }
                    c2.set_Imaginary(-num);
                }
                else
                {
                    JOptionPane.showMessageDialog(null,"<i>Invallid complex number--"+f2.getText());
                    return;
                }
                String opcalc=operators.getSelectedItem().toString();
                complex c3=new complex();
                if(opcalc.equals("+"))
                {
                    c3=c3.add(c1,c2);
                }
                else if(opcalc.equals("-"))
                {
                    c3=c3.minus(c1, c2);
                }
                else if(opcalc.equals("*"))
                {
                    c3=c3.mul(c1,c2);
                }
                else
                {
                   c3=c3.div(c1,c2);
                }
                String message="<html><body><h3>RESULT:"+c3.to_Str()+"<h3></body></html>";
                result.setText(message);
            }
        });
        p2.add(f1);
        p2.add(operators);
        p2.add(f2);
        p2.add(b1);
        this.add(p2);
    }
    void panel3()
    {
        p3=new JPanel();
        p3.setLayout(new FlowLayout(FlowLayout.CENTER,10,10));
        p3.setSize((int)(0.95*this.getWidth()),(int)0.3*this.getHeight());
        result=new JLabel();
        result.setSize((int)(p3.getWidth()*0.95),(int)(0.16*p3.getHeight()));
        result.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        p3.add(result);
        this.add(p3);
    }
    private void make_menu()
    {
        JMenuBar bar=new JMenuBar();
        this.setJMenuBar(bar);
        JMenu men=new JMenu("EDIT");
        JMenuItem it1=new JMenuItem("SAVE");
        JMenuItem it2=new JMenuItem("QUIT");
        it1.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae)
            {
                
            }
        });
        it2.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae)
            {
                System.exit(0);
            }
        });
        men.add(it1);
        men.add(it2);
        bar.add(men);
    }
    public Window()
    {
        super("Complex project");
        this.setSize(300,300);
        this.setLayout(new GridLayout(0,1));
        this.setResizable(false);
        make_menu();
        this.panel1();
        this.panel2();
        this.panel3();
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }
}
