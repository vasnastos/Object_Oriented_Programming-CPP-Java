import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class window extends JFrame{
   private JTextField pages,visitors,iterations;
   private Surfer s;
   private void make_menu()
   {
	   JMenuBar bar=new JMenuBar();
	   this.setJMenuBar(bar);
	   JMenu menu=new JMenu("OPTIONS");
	   ImageIcon ic1=new ImageIcon(new ImageIcon("info.png").getImage().getScaledInstance(20,20,Image.SCALE_REPLICATE));
	   ImageIcon ic2=new ImageIcon(new ImageIcon("adj.jpg").getImage().getScaledInstance(20,20, Image.SCALE_REPLICATE));
	   ImageIcon ic3=new ImageIcon(new ImageIcon("exit.png").getImage().getScaledInstance(20,20,Image.SCALE_REPLICATE));
	   JMenuItem it1=new JMenuItem("SAVE ALGO INFO",ic1);
	   JMenuItem it2=new JMenuItem("ADJACENCY MATRIX",ic2);
	   JMenuItem it3=new JMenuItem("EXIT",ic3); 
	   it1.addActionListener(new ActionListener()
	   {
		   public void actionPerformed(ActionEvent ae)
		   {
			  try {
				Surfer.save_surfing();
			} catch (IOException e) {
			    System.err.print("File did not open properly");
			}
		   }
	   });
	   it2.addActionListener(new ActionListener()
	   {
		   public void actionPerformed(ActionEvent ae)
		   {
			   JOptionPane.showMessageDialog(null,matrix.adj_matrix);
		   }
	   });
	   it3.addActionListener(new ActionListener()
	  {
		   public void actionPerformed(ActionEvent ae)
		   {
			   int op=JOptionPane.showConfirmDialog(null,"<html><b>Do you want to exit the app</b></html>","EXIT APP",JOptionPane.YES_NO_OPTION);
			   if(op==JOptionPane.YES_OPTION)
			   {
				   System.exit(0);
			   }
		   }
	  });
	   menu.add(it1);
	   menu.add(it2);
	   menu.add(it3);
	   bar.add(menu);
   }
   private void panel1()
   {
	   JPanel p1=new JPanel();
	   p1.setLayout(new GridLayout(0,2,10,50));
	   JLabel lb=new JLabel("VISITORS",JLabel.CENTER);
	   lb.setForeground(Color.RED);
	   lb.setBorder(BorderFactory.createLineBorder(Color.BLUE));
	   visitors=new JTextField(5);
	   visitors.setBorder(BorderFactory.createLineBorder(Color.blue));
	   p1.add(lb);
	   p1.add(visitors);
	   this.add(p1);
   }
   private void panel2()
   {
	   JPanel p2=new JPanel();
	   p2.setLayout(new GridLayout(0,2,10,50));
	   JLabel lb=new JLabel("PAGES",JLabel.CENTER);
	   lb.setBorder(BorderFactory.createLineBorder(Color.blue));
	   lb.setForeground(Color.RED);
	   pages=new JTextField(5);
	   pages.setBorder(BorderFactory.createLineBorder(Color.blue));
	   p2.add(lb);
	   p2.add(pages);
	   this.add(p2);
   }
   private void panel3()
   {
	   JPanel p3=new JPanel();
	   p3.setLayout(new GridLayout(0,2,10,50));
	   JLabel lb=new JLabel("ITERATIONS",JLabel.CENTER);
	   lb.setBorder(BorderFactory.createLineBorder(Color.blue));
	   lb.setForeground(Color.red);
	   iterations=new JTextField(5);
	   iterations.setBorder(BorderFactory.createLineBorder(Color.blue));
	   p3.add(lb);
	   p3.add(iterations);
	   this.add(p3);
   }
   private void buttonpanel()
   {
	   JPanel p4=new JPanel();
	   p4.setLayout(new GridLayout(0,2,10,50));
	   JButton b1=new JButton("SURFING");
	   b1.setForeground(Color.green);
	   JButton b2=new JButton("RANKING");
	   b2.setForeground(Color.green);
	   b1.addActionListener(new ActionListener()
	   {

		@Override
		public void actionPerformed(ActionEvent arg0) {
			if(window.this.pages.getText().isEmpty() || window.this.visitors.getText().isEmpty() || window.this.iterations.getText().isEmpty())
			{
				JOptionPane.showMessageDialog(null,"<html><h3 style=\"color:red;\">Please fill all the blanks</h3>","Error Message",JOptionPane.ERROR_MESSAGE);
				return;
			}
			int visitors=Integer.parseInt(window.this.visitors.getText());
			int pages=Integer.parseInt(window.this.pages.getText());
			int iters=Integer.parseInt(window.this.iterations.getText());
			window.this.s=new Surfer(pages);
			window.this.s.Random_surfing(visitors, iters);
		}
		   
	   });
	   b2.addActionListener(new ActionListener()
	   {
		   public void actionPerformed(ActionEvent ae)
		   {
			   if(Surfer.rank.isEmpty())
			   {
				   JOptionPane.showMessageDialog(null,"<html><h3 style=\"color:red;\">No Surfing made</h3>","error",JOptionPane.ERROR_MESSAGE);
				   return;
			   }
			   JOptionPane.showMessageDialog(null,Surfer.rank);
		   }
	   });
	   p4.add(b1);
	   p4.add(b2);
	   this.add(p4);
   }
   public window()
   {
	   this.setSize(400,400);
	   this.setTitle("Random Surfer");
	   this.setLayout(new GridLayout(0,1,20,60));
	   this.make_menu();
	   this.panel1();
	   this.panel2();
	   this.panel3();
	   this.buttonpanel();
	   this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	   this.setResizable(false);
	   this.setVisible(true);
   }
}
