import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;
import java.util.Vector;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class Surfer extends matrix{
	private static double DAMPING_FACTOR =0.85;
	public static String surfing="";
	public static String rank="";
	private int go_to(int r)
	{
		int goalvertex;
		Vector <Integer> neibourghs=this.neibourghs(r);
		double decision=this.r.nextDouble();
		if(neibourghs.size()==0)
		{
			goalvertex=this.r.nextInt(this.size);
			while(goalvertex==r)
			{
				goalvertex=this.r.nextInt(this.size);
			}
			return goalvertex;
		}
		if(decision>1-Surfer.DAMPING_FACTOR)
		{
			goalvertex=this.r.nextInt(neibourghs.size());
			return neibourghs.get(goalvertex);
		}
		goalvertex=this.r.nextInt(this.size);
		while(goalvertex==r)
		{
			goalvertex=this.r.nextInt(this.size);
		}
		return goalvertex;
	}
	public Surfer(int a)
	{
		super(a);
	}
	public void Random_surfing(int visitors,int iterations)
	{
		boolean check=false;
		int startingpoints[]=new int[visitors];
		String htmlview="";
		String info="";
		while(!check)
		{
		     info="";
			this.reset();
			htmlview="<html><center><table border=\"3\" style=\"background-color:#dbf0a1; color:blue; font-size:13px; text-align:center;\">";
			htmlview+="<tr><th>VISITOR</th><th>FROM</th><td>TO</th></tr>";
			for(int i=0;i<visitors;i++)
			{
				int temp=this.r.nextInt(this.size);
				startingpoints[i]=temp;
				this.add_visit(temp);
			}
			for(int i=0;i<iterations;i++)
			{
		       if(i!=0)
		       {
		    	   htmlview+="<tr><td></td><td></td><td></td></tr>";
		       }
				for(int j=0;j<visitors;j++)
				{
					int nextpage=this.go_to(startingpoints[j]);
					htmlview+="<tr><td>Vistor "+String.valueOf(j+1)+"</td><td>Web Page "+String.valueOf(startingpoints[j])+"</td><td>"+String.valueOf(nextpage)+"</td></tr>";
					info+="Visitor "+String.valueOf(j+1)+" goes from web Page "+String.valueOf(startingpoints[j])+" to web Page "+String.valueOf(nextpage)+"\n";
					this.add_visit(nextpage);
					startingpoints[j]=nextpage;
				}
			}
			htmlview+="</table></center></html>";
			Surfer.rank=this.find_ranking();
			check=this.difference();
		}
		info+="\n\n\t\tVISITS\n";
		info+="\tWeb Page\tVisit_Number\n";
		for(int i=0;i<this.size;i++)
		{
			info+="\t"+String.valueOf(i)+"     \t  "+String.valueOf(this.visits[i])+"\n";
		}
	    info+="\n\n\t\tRanking\n";
	    info+="\tWeb Page  \tRank\n";
	    for(int i=0,t=this.ranking.size();i<t;i++)
	    {
	    	info+="\t"+String.valueOf(this.ranking.get(i).webPage)+"\t "+String.format("%.3f",this.ranking.get(i).rank)+"\n";
	    }
	    Surfer.surfing=info;
		JOptionPane.showMessageDialog(null,htmlview);
	}
	public static void save_surfing() throws IOException
	{
		JFileChooser ch=new JFileChooser();
		int rval=ch.showSaveDialog(null);
		if(rval==JFileChooser.APPROVE_OPTION)
		{
			String filename=ch.getSelectedFile().getAbsolutePath();
			FileWriter fw=new FileWriter(filename);
			PrintWriter pw=new PrintWriter(fw);
			pw.println("\tFile Created at:"+java.time.LocalDateTime.now().toString());
			pw.println("\t�Nastos Vasileios 2020 Arta");
			pw.println("\tRandom Surfer Algorithm");
			pw.println("\tSurfing Information");
			pw.println("***************************************************************");
			pw.println(Surfer.surfing);
			pw.close();
		}
	}
}
