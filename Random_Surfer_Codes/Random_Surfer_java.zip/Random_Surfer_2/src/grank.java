
public class grank implements Comparable<grank>{
   public String webPage;
   public double rank;
   public grank(int a,double r)
   {
	   this.webPage="WebPage "+String.valueOf(a);
	   this.rank=r;
   }
@Override
public int compareTo(grank arg0) {
	return Double.compare(this.rank,arg0.rank);
}
}
