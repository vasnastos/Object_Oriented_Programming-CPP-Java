
import java.util.LinkedList;
import java.util.Random;
import java.util.Vector;

public class matrix {
    protected int adj[][];
    protected int size;
    protected LinkedList <grank> ranking;
    public static String adj_matrix="";
    protected int visits[];
    protected Random r=new Random(System.currentTimeMillis());
    public matrix(int a)
    {
    	adj_matrix="<html><center><table border=\"3\" style=\"color:red;\">";
    	size=a;
    	this.adj=new int[a][a];
    	this.visits=new int[a];
    	for(int i=0;i<a;i++)
    	{
    		this.visits[i]=0;
    		for(int j=0;j<a;j++)
    		{
    			if(i==j)
    			{
    				adj[i][j]=0;
    				continue;
    			}
    			adj[i][j]=r.nextInt(2);
    		}
    	}
    	adj_matrix+="<tr>";
    	for(int i=0;i<a;i++)
    	{
    		adj_matrix+="<th>Web Page "+String.valueOf(i+1)+"</th>";
    	}
    	adj_matrix+="</tr>";
    	for(int i=0;i<a;i++)
    	{
    		adj_matrix+="<tr>";
    		for(int j=0;j<a;j++)
    		{
    			 adj_matrix+="<td>"+String.valueOf(adj[i][j])+"</td>";
    		}
    		adj_matrix+="</tr>";
    	}
    	adj_matrix+="</table></center></html>";
    	this.ranking=new LinkedList<grank>();
    }
    public void add_visit(int r)
    {
    	this.visits[r]++;
    }
    public Vector <Integer> neibourghs(int vertex)
    {
    	Vector <Integer> nbs=new Vector<Integer>();
    	for(int j=0;j<this.size;j++)
    	{
    		if(this.adj[vertex][j]!=0)
    		{
    			nbs.add(j);
    		}
    	}
    	return nbs;
    }
    public boolean difference()
    {
    	double initialrank=this.ranking.get(0).rank;
    	double finalrank=this.ranking.get(this.ranking.size()-1).rank;
    	return initialrank-finalrank<=0.05;
    }
    public void reset()
    {
    	for(int i=0;i<this.size;i++)
    	{
    		this.visits[i]=0;
    	}
    	this.ranking.clear();
    	this.r=new Random(System.currentTimeMillis());
    }
    public String find_ranking()
    {
    	String htmlmessage="<html><center><table border=\"3\" style=\"text-align:center; background-color:#dbf0a1; color:blue; font-size:10px;\">";
    	htmlmessage+="<tr><td>WEBPAGE</td><td>RANK</td></tr>";
    	for(int i=0;i<this.size;i++)
    	{
    		grank g=new grank(i,(double)this.visits[i]/(this.size*this.size));
    		this.ranking.add(g);
    	}
    	this.ranking.sort(null);
    	grank temp;
    	for(int i=0,t=this.ranking.size();i<t/2;i++)
    	{
    		temp=this.ranking.get(i);
    		this.ranking.set(i,this.ranking.get(t-i-1));
    		this.ranking.set(t-i-1,temp);
    	}
    	final int size=this.ranking.size();
    	int i=0;
    	while(i<size)
    	{
    		htmlmessage+="<tr><td>"+this.ranking.get(i).webPage+"</td><td>"+String.valueOf(this.ranking.get(i).rank)+"</td></tr>";
    	    i++;
    	}
    	htmlmessage+="</table></center></html>";
    	return htmlmessage;
    }
}
