#include <iostream>
#include <iomanip>
#include <random>
#include <chrono>
#include <vector>
#include "matrix.hpp"

using namespace std;

int main()
{
    int n = 5; // Ξ±ΟΞΉΞΈΞΌΟΟ ΞΉΟΟΞΏΟΞ΅Ξ»Ξ―Ξ΄ΟΞ½
    int s = 2; // Ξ±ΟΞΉΞΈΞΌΟΟ Ξ΅ΟΞΉΟΞΊΞ΅ΟΟΟΞ½

    long seed = 123456789l; // Ξ―Ξ΄ΞΉΞ± Ξ±ΟΞΏΟΞ΅Ξ»Ξ­ΟΞΌΞ±ΟΞ± ΞΊΞ¬ΞΈΞ΅ ΟΞΏΟΞ¬ ΟΞΏΟ Ξ΅ΞΊΟΞ΅Ξ»Ξ΅Ξ―ΟΞ±ΞΉ ΟΞΏ ΟΟΟΞ³ΟΞ±ΞΌΞΌΞ±
    // long seed = chrono::system_clock::now().time_since_epoch().count(); // // Ξ΄ΞΉΞ±ΟΞΏΟΞ΅ΟΞΉΞΊΞ¬ Ξ±ΟΞΏΟΞ΅Ξ»Ξ­ΟΞΌΞ±ΟΞ± ΞΊΞ¬ΞΈΞ΅ ΟΞΏΟΞ¬ ΟΞΏΟ Ξ΅ΞΊΟΞ΅Ξ»Ξ΅Ξ―ΟΞ±ΞΉ ΟΞΏ ΟΟΟΞ³ΟΞ±ΞΌΞΌΞ±
    mt19937 engine(seed);
    uniform_int_distribution<int> dist1 = uniform_int_distribution<int>(0, 1); // ΟΟΞ·ΟΞΉΞΌΞΏΟΞΏΞΉΞ΅Ξ―ΟΞ±ΞΉ Ξ³ΞΉΞ± ΟΞ·Ξ½ ΟΟΟΞ±Ξ―Ξ± Ξ΄Ξ·ΞΌΞΉΞΏΟΟΞ³Ξ―Ξ± ΟΞΏΟ Ξ³ΟΞ±ΟΞ�ΞΌΞ±ΟΞΏΟ ΟΟΞ½Ξ΄Ξ­ΟΞ΅ΟΞ½
    uniform_int_distribution<int> dist2 = uniform_int_distribution<int>(0, n); // ΟΟΞ·ΟΞΉΞΌΞΏΟΞΏΞΉΞ΅Ξ―ΟΞ±ΞΉ Ξ³ΞΉΞ± ΟΞ·Ξ½ ΟΟΟΞ±Ξ―Ξ± ΟΞΏΟΞΏΞΈΞ­ΟΞ·ΟΞ· Ξ΅ΟΞΉΟΞΊΞ΅ΟΟΟΞ½ ΟΞ΅ ΞΉΟΟΞΏΟΞ΅Ξ»Ξ―Ξ΄Ξ΅Ο

    // ΞΞ·ΞΌΞΉΞΏΟΟΞ³Ξ―Ξ± Ξ³ΟΞ±ΟΞ�ΞΌΞ±ΟΞΏΟ
    Matrix links(n, n); // Ξ΄ΞΉΟΞ΄ΞΉΞ¬ΟΟΞ±ΟΞΏΟ ΟΞ―Ξ½Ξ±ΞΊΞ±Ο ΟΞΏΟ ΟΞ΅ΟΞΉΞ­ΟΞ΅ΞΉ ΟΞ·Ξ½ ΟΞ»Ξ·ΟΞΏΟΞΏΟΞ―Ξ± ΟΟΞ½Ξ΄Ξ΅ΟΞ·Ο Ξ±Ξ½Ξ¬ΞΌΞ΅ΟΞ± ΟΟΞΉΟ ΞΉΟΟΞΏΟΞ΅Ξ»Ξ―Ξ΄Ξ΅Ο
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (i == j)
                continue;
            links[i][j] = dist1(engine);
        }
    }

    cout << "The graph is the following:" << endl;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            cout << setw(2) << links[i][j];
        }
        cout << endl;
    }

    cout << "Initial positions" << endl;
    // Ξ€ΞΏΟΞΏΞΈΞ­ΟΞ·ΟΞ· ΟΟΞ½ Ξ΅ΟΞΉΟΞΊΞ΅ΟΟΟΞ½ ΟΞ΅ ΟΟΟΞ±Ξ―Ξ΅Ο ΞΊΞΏΟΟΟΞ­Ο ΟΞΏΟ Ξ³ΟΞ±ΟΞ�ΞΌΞ±ΟΞΏΟ
    int *surfer_position = new int[s];
    for (int i = 0; i < s; i++)
    {
        surfer_position[i] = dist2(engine);
        cout << "Surfer " << i << " is in web page " << surfer_position[i] << endl;
    }

    // ΞΌΞ΅ΟΞ±ΞΊΞ―Ξ½Ξ·ΟΞ· ΟΟΞ½ Ξ΅ΟΞΉΟΞΊΞ΅ΟΟΟΞ½ Ξ±ΟΟ ΟΞ· ΟΞ΅Ξ»Ξ―Ξ΄Ξ± ΟΞΏΟ Ξ²ΟΞ―ΟΞΊΞΏΞ½ΟΞ±ΞΉ ΟΞ΅ ΞΌΞΉΞ± Ξ¬Ξ»Ξ»Ξ· (10 Ξ΅ΟΞ±Ξ½Ξ±Ξ»Ξ�ΟΞ΅ΞΉΟ)
    for (int r = 0; r < 10; r++)
    {
        cout << "Round " << r << endl;
        for (int surfer_id = 0; surfer_id < s; surfer_id++)
        {
            int current_page = surfer_position[surfer_id];
            vector<int> neighbors;
            for (int j = 0; j < n; j++)
            {
                if (links[current_page][j] == 1)
                {
                    neighbors.push_back(j);
                }
            }
            if (neighbors.empty())
            {
                cout << "Dead end for surfer " << surfer_id << endl;
                continue;
            }
            int next_page = neighbors[dist2(engine) % neighbors.size()];
            cout << "Surfer " << surfer_id << " moves from web page " << current_page << " to web page " << next_page << endl;
            surfer_position[surfer_id] = next_page;
        }
    }

    delete[] surfer_position;
}